
========================================
Vui lòng mã hóa tệp assets/js/index.js nếu đã edit xong, nếu không mã hóa bạn bật anti-f12 sẽ giảm độ bảo vệ.

Nếu vào trang bị lỗi trắng, đó là do mã hóa không hỗ trợ, hãy thử đổi website mã hóa khác

Mã hóa tại trang: https://www.lddgo.net/en/encrypt/js ( chọn medium obfuscator )

Đường dẫn config/config.js dùng để chỉnh sửa thông tin

Đường dẫn inc/common.php đùng dể edit thông số website

Vui lòng chỉnh sửa theo sở thích của mình

Github: https://github.com/WusThanhDieu?tab=repositories
========================================
