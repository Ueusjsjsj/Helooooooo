    <script src="./assets/js/jquery-3.4.1.min.js?<?=RandCache()?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>
    <script src="./config/config.js?<?=RandCache()?>"></script>
    <script src="./assets/js/plugins.js?<?=RandCache()?>"></script>
    <script src="./assets/js/common@v1.js?<?=RandCache()?>"></script>
    <script src="./assets/js/index.js?<?=RandCache()?>"></script>
    <script src="./assets/js/map.init.js?<?=RandCache()?>"></script>
    <script src="./assets/js/js.cookie.js?<?=RandCache(30)?>"></script>
    <?php if ($_CONF['anti-f12-pro']): ?>
<script src="./assets/layui/hex-2.js?<?=RandCache()?>"></script>
    <?php endif; ?><?php if ($_CONF['anti-f12-basic']): ?>
    <script src="./assets/layui/hex-1.js?<?=RandCache()?>"></script>
    <?php endif; ?><?php if ($_CONF['combo-anti-ctrl+u']): ?>
     <script src="./assets/layui/control.js?<?=RandCache()?>"></script><?php endif; ?><?php if ($_CONF['effect-hoaroi']): ?>
<script src="./assets/layui/hoa-roi.js?<?=RandCache()?>"></script><?php endif; ?>
    <?php if ($_CONF['obf-resource-basic']): ?>
    <script src="./assets/layui/hex-3.js?<?=RandCache()?>"></script>
    <?php endif; ?><?php if ($_CONF['effect-porn-up']): ?>

    <script src="./assets/layui/porn-up.js?<?=RandCache()?>"></script>
    <?php endif; ?><?php if ($_CONF['effect-click']): ?><script src="./assets/layui/click-effect.js?<?=RandCache()?>"></script><?php endif; ?></body>
  </html>
  <!--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                   _ooOoo_
                  o8888888o
                  88" . "88
                  (| -_- |)
                  O\  =  /O
               ____/`---'\____
             .'  \\|     |//  `.
            /  \\|||  :  |||//  \
           /  _||||| -:- |||||-  \
           |   | \\\  -  /// |   |
           | \_|  ''\---/''  |   |
           \  .-\__  `-`  ___/-. /
         ___`. .'  /--.--\  `. . __
      ."" '<  `.___\_<|>_/___.'  >'"".
     | | :  `- \`.;`\ _ /`;.`/ - ` : | |
     \  \ `-.   \_ __\ /__ _/   .-` /  /
======`-.____`-.___\_____/___.-`____.-'======
                   `=---='
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
       PHẬT ĐỘ   KHÔNG LỖI   KHÔNG BUG
              VUONG THANH DIEU
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-->