//=========================================================//
var config_name = ['fullname', 'username','website','zalo','avatar','facebook'];
var config_aboutme = ['thathinh', 'chamngon'];
var config_stk = ['mbbank', 'momo','vietinbank','vietcombank'];
//=========================================================//
var set_1 = {
    fullname: 'Vương Thanh Diệu',
    username: 'wusthanhdieu',
    website: 'stk.thanhdieu.com', // Lưu ý đây là tên miền hiện tại của website, ví dụ https://thanhdieu.com thì chỉ lấy thanhdieu.com
    zalo: 'vuongdieu2k3',
    avatar: 'https://upload.thanhdieu.com/3ba7d4.gif',
    facebook: 'https://fb.com/wusthanhdieu',
};
//=========================================================//
var set_2 = {
    thathinh: 'Anh không hoàn hảo, nhưng anh là duy nhất',
    chamngon: 'Từ 1 cậu bé hư hổng, thất học nhưng lại suốt ngày mơ ước muốn trở thành lập trình viên',
};
//=========================================================//
var set_3 = {
    mbbank: {
       sotaikhoan: '0123456789',
        chutaikhoan: 'Vương Thanh Diệu',
    },
    momo: {
        sotaikhoan: '0123456789',
        chutaikhoan: 'Vương Thanh Diệu',
    },
    vietinbank: {
        sotaikhoan: '0123456789',
        chutaikhoan: 'Vương Thanh Diệu',
    },
    vietcombank: {
        sotaikhoan: 'Đang cập nhật...',
        chutaikhoan: 'Đang cập nhật...',
    }
};
//=========================================================//