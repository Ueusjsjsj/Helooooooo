<?php 
header("location: ../");