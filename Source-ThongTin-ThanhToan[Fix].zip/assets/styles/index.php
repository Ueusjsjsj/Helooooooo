<?php 
header("Location ../");